package ru.oogis.searadar.api.types;

public enum TargetType {
    SURFACE, AIR, UNKNOWN
}
