package ru.oogis.hydra.config;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "hydra")
@XmlAccessorType(XmlAccessType.FIELD)
public class HydraConfig extends ConfigElement
{
	
}
